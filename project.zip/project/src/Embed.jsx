import Chatbot from "./Chatbot";

export default function Embed() {
  return (
    <div style={{ height: "100vh", width: "100vw", margin: 0 }}>
      <Chatbot />
    </div>
  );
}
